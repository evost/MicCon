#PS/2 Keyboard Library#

PS2Keyboard allows you to use a keyboard for user input. 

http://www.pjrc.com/teensy/td_libs_PS2Keyboard.html

![](http://www.pjrc.com/teensy/td_libs_PS2Keyboard.jpg)
